## Module <om_hr_payroll>

#### 25.12.2023
#### Version 17.0.1.0.0
##### ADD
- initial release